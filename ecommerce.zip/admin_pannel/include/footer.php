
        <footer>
        <p>2020 - 2020 © Ifotechsys.</p>
        </footer>
    </div>



    <script src ="admin.js"></script>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/221cbd1801.js" crossorigin="anonymous"></script>

</html>