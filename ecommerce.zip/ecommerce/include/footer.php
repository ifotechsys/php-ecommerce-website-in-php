
        <!-- ----------------------------------------------footer---------------------------------------------- -->
        <!-- ---Footer--- -->
        <div class="footer">
            <div class="footer_top container-fluid">
                <div class="row">
                    <div class="col-md-9">
                        <div class="row">
                            <div class="col-md-3">
                                <p class="myList_title">All
                                    Categories</p>
                                <ul class="list-group myList">
                                    <li class="list-group-item list-group-item-action myList_item">
                                        <a href="#"> Grocery
                                        </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item">
                                        <a href="#">
                                            Electronics
                                        </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item">
                                        <a href="#"> Fashion
                                        </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item">
                                        <a href="#"> Beauty
                                        </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item">
                                        <a href="#"> Home &
                                            Kitchen </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item">
                                        <a href="#"> Premium
                                            Fruits </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item">
                                        <a href="#"> Books
                                        </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item">
                                        <a href="#">
                                            Furniture
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-3">
                                <p class="myList_title">
                                    Popular
                                    Categories</p>
                                <ul class="list-group myList">
                                    <li class="list-group-item list-group-item-action myList_item ">
                                        <a href="#"> Staples
                                        </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item ">
                                        <a href="#">
                                            Beverages
                                        </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item ">
                                        <a href="#">
                                            Personal
                                            Care </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item ">
                                        <a href="#"> Home
                                            Care
                                        </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item ">
                                        <a href="#"> Fruits
                                            &
                                            Vegetables </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item">
                                        <a href="#"> Baby
                                            Care
                                        </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item">
                                        <a href="#"> Snacks
                                            &
                                            Branded Foods
                                        </a>
                                    </li>
                                    <li class="list-group-item list-group-item-action myList_item">
                                        <a href="#"> Dairy &
                                            Bakery </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-3">
                                <p class="myList_title">
                                    Customer
                                    Account</p>
                                <ul class="list-group myList">
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#"> My
                                            Account
                                        </a>
                                    </li>
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#"> My
                                            Orders
                                        </a>
                                    </li>
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#">
                                            Wishlist
                                        </a>
                                    </li>
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#"> Payment
                                            Methods </a>
                                    </li>
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#">
                                            Delivery
                                            Addresses </a>
                                    </li>
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#"> JioMart
                                            Wallet </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-3">
                                <p class="myList_title">Help
                                    &
                                    Support</p>
                                <ul class="list-group myList">
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#"> About
                                            Us
                                        </a>
                                    </li>
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#"> FAQ
                                        </a>
                                    </li>
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#"> Terms &
                                            Conditions </a>
                                    </li>
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#"> Privacy
                                            Policy </a>
                                    </li>
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#"> E-waste
                                            Policy </a>
                                    </li>
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#">
                                            Cancellation &
                                            Return Policy
                                        </a>
                                    </li>
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#">
                                            Shipping &
                                            Delivery Policy
                                        </a>
                                    </li>
                                    <li class=" list-group-item list-group-item-action myList_item">
                                        <a href="#"> AC
                                            Installation by
                                            resQ
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <p class="contact">Contact Us</p>
                        <div class="contact_item">
                            <div class="whatsup d-md-flex gap-1">
                                <p> WhatsApp us:</p>
                                <a class="footer-top-sub-contact-item-link"
                                    href="https://wa.me/917008438639"><?=whatsup;?></a>
                            </div>
                            <div class="call d-md-flex gap-1">
                                <p>Call us:</p>
                                <a class="footer-top-sub-contact-item-link"
                                    href="tel:+9118008901222"><?=callus;?></a>
                            </div>
                            <div class="time">
                                <p>8:00 AM to 8:00 PM, 365
                                    days
                                </p>
                            </div>
                        </div>
                        <div class="contact_item mt-3">
                            <p>Should you encounter any
                                bugs,
                                glitches, lack of
                                functionality,
                                delayed deliveries, billing
                                errors or other problems on
                                the
                                website, please email us on
                                <a class="footer-top-sub-contact-item-link"
                                    href="mailto:cs@jiomart.com"><?=email;?></a>
                            </p>
                        </div>
                        <div class="footer_app">
                            <p class="h3">Download the app
                            </p>
                            <div class="d-md-flex gap-3">
                                <img src="images/svg_images/google-play-icon.svg" alt="google icon">
                                <img src="images/svg_images/ios_app_icon.svg" alt="ios icon">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer_bottom d-md-flex justify-content-between">
                <div class="footer_botom_left d-md-flex align-items-center gap-2">
                    <img src="images/svg_images/jiomart-logo-icon.svg" alt="jiomart-logo">
                    <p class="">© 2024 All rights reserved.
                        Reliance Retail Ltd.</p>
                </div>
                <div class="footer_botom_right d-md-flex align-items-center ">
                    <p class="">Best viewed on Microsoft
                        Edge
                        81+, Mozilla Firefox 75+, Safari
                        5.1.5+,
                        Google Chrome 80+</p>
                </div>
            </div>
        </div>

        <!-- -----srarch-Bar popup----- -->
        <div class="modal mt-5" id="mySearch">
            <div class="modal-dialog modal-md">
                <div class="modal-content myModalContent">
                    <div class="modal-body myModalBody">
                        <div class="Discover_more mt-4">
                            <h2 class="fs-5">Discover More
                            </h2>
                            <div class="button">
                                <button type="button" class="btn searchButton"><a class="text-black"
                                        href="#">Biscuits</a></button>
                                <button type="button" class="btn searchButton"><a class="text-black"
                                        href="#">sugar</a></button>
                                <button type="button" class="btn searchButton"><a class="text-black"
                                        href="#">oil</a></button>
                                <button type="button" class="btn searchButton"><a class="text-black" href="#">mustard
                                        oil</a></button>
                                <button type="button" class="btn searchButton"><a class="text-black"
                                        href="#">atta</a></button>
                                <button type="button" class="btn searchButton"><a class="text-black" href="#">bharat
                                        rice</a></button>
                                <button type="button" class="btn searchButton"><a class="text-black" href="#">surf
                                        excel</a></button>
                                <button type="button" class="btn searchButton"><a class="text-black"
                                        href="#">chocolate</a></button>
                                <button type="button" class="btn searchButton"><a class="text-black"
                                        href="#">ghee</a></button>
                                <button type="button" class="btn searchButton"><a class="text-black"
                                        href="#">magie</a></button>
                            </div>
                        </div>
                        <div class="Popular_Categories mt-5">
                            <h6>Popular Categories</h6>
                            <div class="d-md-flex overflow-x-auto gap-4">
                                <div class="categories">
                                    <img src="images/beauty.webp" alt="categories">
                                    <p>Beauty</p>
                                </div>
                                <div class="categories">
                                    <img src="images/beauty.webp" alt="categories">
                                    <p>Beauty</p>
                                </div>
                                <div class="categories">
                                    <img src="images/beauty.webp" alt="categories">
                                    <p>Beauty</p>
                                </div>
                                <div class="categories">
                                    <img src="images/beauty.webp" alt="categories">
                                    <p>Beauty</p>
                                </div>
                                <div class="categories">
                                    <img src="images/beauty.webp" alt="categories">
                                    <p>Beauty</p>
                                </div>
                                <div class="categories">
                                    <img src="images/beauty.webp" alt="categories">
                                    <p>Beauty</p>
                                </div>
                                <div class="categories">
                                    <img src="images/beauty.webp" alt="categories">
                                    <p>Beauty</p>
                                </div>
                                <div class="categories">
                                    <img src="images/beauty.webp" alt="categories">
                                    <p>Beauty</p>
                                </div>
                                <div class="categories">
                                    <img src="images/beauty.webp" alt="categories">
                                    <p>Beauty</p>
                                </div>
                                <div class="categories">
                                    <img src="images/beauty.webp" alt="categories">
                                    <p>Beauty</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <!-- -----srarch-Bar list-popup----- -->
        <div class="modal" id="mylist">
            <div class="modal-dialog modal-md">
                <div class="modal-content listPopup_cnt">
                    <div class="modal-header Shopping">
                        <h2 class="h3">Shopping List</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="shopping-list-subtext modal-body myModelBody">
                        <p class="subtext">Search multiple products by entering
                            your shopping list below.</p>
                        <div class="wrapper">
                            <label class="field-label subtext" for="shopping-list">Enter
                                Item List</label>
                            <textarea id="rel_search_val" name="shopping-list" type="textarea" rows="1"
                                placeholder="e.g. Milk, Bread, Fruit"
                                class="input-component custom-scrollbar"></textarea>
                        </div>
                        <p class="subtext">Add comma as separatror</p>
                    </div>

                    <div class="modal-footer myModelFooter">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-6 listPopup_btn listPopup_Close_btn">
                                    <button class="btn Close_btn" data-bs-dismiss="modal">Close</button>
                                </div>
                                <div class="col-md-6 listPopup_btn">
                                    <button class="btn btn-primary Submit_btn" type="submit">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ----------viewAll Bank Offer--------- -->
        <div class="offcanvas offcanvas-end" id="viewAll_BankOffer">
            <div class="offcanvas-header justify-content-between">
                <h5 class="offcanvas-title offers" id="offcanvasRightLabel"> Offers (2)</h5>
                <div class="offerClosebtn">
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
                </div>
            </div>
            <div class="offcanvas-body">
                <div class="d-md-flex gap-2">
                    <img src="images/product/product_ditel/svg/bank-offer-icon.svg" class="bankIcon" alt="bank-offer-icon">
                    <div>
                        <div class="bank_offer"> BANK OFFERS </div>
                        <div class="twoOffers"> Save more with your preferred bank! </div>
                    </div>
                </div>
                <div class="content_caption content_caption1 d-flex mt-3 pt-2">
                    <div>
                        <p>Get upto Rs.75 Cashback on your first ever Mobikwik Wallet transaction on
                            JioMart . Min.Order Value of Rs 499</p>
                    </div>
                    <div class="right-icon"><img src="images/product/product_ditel/svg/chevron-right-icon.svg"
                            alt="right-icon"></div>
                </div>
                <div class="content_caption d-flex mt-2">
                    <div>
                        <p>Get upto Rs.100 cashback on using CRED UPI for Min. Order Value of Rs 199</p>
                    </div>
                    <div class="right-icon"><img src="images/product/product_ditel/svg/chevron-right-icon.svg"
                            alt="right-icon"></div>
                </div>
            </div>
        </div>
        
        <!-- ----------Deliver to----------- -->
        <div class="modal" id="delivery-to-icon">
            <div class="modal-dialog" style="
                    margin-top: 0px">
                <div class="modal-content locationContent">
                    <div class="modal-header locationHeader">
                        <h2 class="modal-title"> Select Delivery Location </h2>
                    </div>
                    <div class="modal-body locationBody">
                        <p> Sign in or set delivery location to see product availability, offers and
                            discounts. </p>
                        <div class="d-grid">
                            <button class="btn btn-primary rounded-pill pt-2 pb-2" type="button">
                                Sign In to select address </button>
                        </div>
                        <div class="d-grid gap-2 col-6 mt-2 deliverLocation">
                            <button type="button" class="btn btn-outline-primary rounded-pill gap-3">
                                <img src="images/product/product_ditel/svg/location-dark.svg" alt="location-dark">
                                Enter a pincode
                            </button>
                            <button type="button" class="btn btn-outline-primary rounded-pill gap-3">
                                <img src="images/product/product_ditel/svg/detect-dark.svg" alt="detect-dark">
                                Detect My Location
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
    </body>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/owl.carousel.min.js"></script>

    <script src="https://use.fontawesome.com/826a7e3dce.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script src="js/script.js"></script>
</html>