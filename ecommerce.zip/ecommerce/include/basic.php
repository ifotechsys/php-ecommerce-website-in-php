<?php
    define('callus', '1800 890 1222');
    define('whatsup','70003 70003');
    define('email','cs@jiomart.com');
    define('address','');
    define('defivery_adress','Hyderabad 400020');
    define('url', 'http://localhost/Ecommerce');
    
?>