 <?php
        include 'include/header.php';
  ?>

<div class="dashboard d-flex justify-content-between align-items-center pe-4">
                    <div class="h4">Dashboard</div>
                    <div class="dsbrdLite h6">Dashboard</div>
                </div>

                <div class="p-3 pt-4">
                    <div class="row order">
                        <div class="col-md-3">
                            <div class="card myCard">
                                <div class="card-header align-items-center myCard_header">Total Order</div>
                                <div class="card-body body1">
                                    <h4 class="d-flex justify-content-center">14</h4>
                                    <div class="d-flex justify-content-center">
                                        <button type="button" class=" btn button1">view order</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card myCard">
                                <div class="card-header myCard_header">Total Order</div>
                                <div class="card-body body2">
                                    <h4 class="d-flex justify-content-center">0</h4>
                                    <div class="d-flex justify-content-center">
                                        <button type="button" class="btn button2">view order</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card myCard">
                                <div class="card-header myCard_header">cancel Order</div>
                                <div class="card-body body3">
                                    <h4 class="d-flex justify-content-center">2</h4>
                                    <div class="d-flex justify-content-center">
                                        <button type="button" class="btn button3">view order</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card myCard">
                                <div class="card-header myCard_header">Earnings</div>
                                <div class="card-body body4">
                                    <h4 class="d-flex justify-content-center">Rs 15,957.00</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>






    <?php
        include 'include/footer.php';
  ?>